﻿using LeetCodeDaily.Core;

namespace $safeprojectname$;

public class Solution
{
    [ResultGenerator]
    public int ResultGenerator(int input1, int input2)
    {
        return input1 + input2;
    }
}