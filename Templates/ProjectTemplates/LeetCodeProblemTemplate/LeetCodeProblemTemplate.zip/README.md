# Problem Title

Problem description

<br/>

**Example 1:**

- **Input:** `input1 = 2`, `input2 = 2`
- **Output:** `4`
- **Explanation:** `2 + 2 = 4`.

**Example 2:**

- **Input:** `input1 = 6`, `input2 = 9`
- **Output:** `15`
- **Explanation:** `6 + 9 = 15`.

<br/>

**Constraints:**

*   `-2`<sup>`31`</sup>` <= input1, input2 <= 2`<sup>`31`</sup>`- 1`